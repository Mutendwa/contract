from __future__ import annotations

import argparse
import re
import shutil
import unicodedata
from pathlib import Path
from typing import Dict, Optional

from openpyxl import load_workbook


def normalize(value: object) -> str:
    """Normalize Excel text, including non-breaking spaces, for matching."""
    if value is None:
        return ""
    text = unicodedata.normalize("NFKC", str(value)).replace("\xa0", " ")
    text = text.casefold().strip()
    text = re.sub(r"[^a-z0-9]+", " ", text)
    return re.sub(r"\s+", " ", text).strip()


def find_sheet(workbook, names: tuple[str, ...]) -> Optional[str]:
    """Find a sheet while ignoring capitalization and extra spaces."""
    normalized = {normalize(name): name for name in workbook.sheetnames}
    for candidate in names:
        key = normalize(candidate)
        if key in normalized:
            return normalized[key]
    return None


def header_map(ws) -> Dict[str, int]:
    return {
        normalize(cell.value): cell.column
        for cell in ws[1]
        if cell.value is not None
    }


def first_header(headers: Dict[str, int], aliases: tuple[str, ...]) -> Optional[int]:
    for alias in aliases:
        column = headers.get(normalize(alias))
        if column:
            return column
    return None


def read_tariffs(ws) -> Dict[str, object]:
    """Read facility tariffs, accepting Negotiated Tariff or AGREED."""
    headers = header_map(ws)
    name_col = first_header(
        headers,
        ("Intervention Name", "Intervention", "Service Name", "Service"),
    )
    tariff_col = first_header(
        headers,
        ("Negotiated Tariff", "AGREED", "Agreed Tariff", "Tariff", "Amount"),
    )

    if not name_col or not tariff_col:
        actual_headers = [str(cell.value).strip() for cell in ws[1] if cell.value is not None]
        raise ValueError(
            f"Sheet '{ws.title}' must contain an intervention column and a tariff column. "
            "Accepted tariff headers include 'Negotiated Tariff' and 'AGREED'. "
            f"Headers found: {actual_headers}"
        )

    tariffs: Dict[str, object] = {}
    for row in range(2, ws.max_row + 1):
        name = normalize(ws.cell(row, name_col).value)
        tariff = ws.cell(row, tariff_col).value
        if name and tariff not in (None, ""):
            tariffs[name] = tariff
    return tariffs


def identify_opd_tariffs(tariffs: Dict[str, object]) -> tuple[Optional[object], Optional[object]]:
    general = None
    specialist = None
    fixed_fee = None

    for key, tariff in tariffs.items():
        if "specialist" in key:
            specialist = tariff
        elif "general" in key and ("practitioner" in key or "practioner" in key):
            general = tariff
        elif "fixed fee" in key or "consultation" in key:
            fixed_fee = tariff

    if general is None:
        general = fixed_fee
    if specialist is None:
        specialist = general if general is not None else fixed_fee

    return general, specialist


def process_imaging(facility_ws, template_ws) -> int:
    tariffs = read_tariffs(facility_ws)
    headers = header_map(template_ws)
    sub_benefit_col = first_header(headers, ("Sub - Benefit", "Sub Benefit"))
    tariff_col = first_header(headers, ("Negotiated Tariff",))
    if not sub_benefit_col or not tariff_col:
        raise ValueError("Template Imaging sheet needs 'Sub - Benefit' and 'Negotiated Tariff'.")

    rows_to_delete = []
    kept = 0
    for row in range(2, template_ws.max_row + 1):
        key = normalize(template_ws.cell(row, sub_benefit_col).value)
        tariff = tariffs.get(key)
        if tariff is None:
            rows_to_delete.append(row)
        else:
            template_ws.cell(row, tariff_col).value = tariff
            kept += 1

    for row in reversed(rows_to_delete):
        template_ws.delete_rows(row)
    return kept


def process_opd(facility_ws, template_ws) -> int:
    tariffs = read_tariffs(facility_ws)
    general_tariff, specialist_tariff = identify_opd_tariffs(tariffs)

    headers = header_map(template_ws)
    intervention_col = first_header(headers, ("Intervention Name",))
    tariff_col = first_header(headers, ("Negotiated Tariff",))
    if not intervention_col or not tariff_col:
        raise ValueError("Template OPD sheet needs 'Intervention Name' and 'Negotiated Tariff'.")

    rows_to_delete = []
    kept = 0
    for row in range(2, template_ws.max_row + 1):
        name = normalize(template_ws.cell(row, intervention_col).value)
        tariff = None
        if "specialist" in name:
            tariff = specialist_tariff
        elif "general" in name and ("practitioner" in name or "practioner" in name):
            tariff = general_tariff
        else:
            tariff = tariffs.get(name)

        if tariff is None:
            rows_to_delete.append(row)
        else:
            template_ws.cell(row, tariff_col).value = tariff
            kept += 1

    for row in reversed(rows_to_delete):
        template_ws.delete_rows(row)
    return kept


def populate_template(output_path: Path, facility_path: Path) -> tuple[int, int]:
    facility_wb = load_workbook(facility_path, data_only=True, read_only=True)
    output_wb = load_workbook(output_path)

    facility_imaging = find_sheet(facility_wb, ("Imaging",))
    facility_opd = find_sheet(facility_wb, ("OPD", "Outpatient"))

    if not facility_imaging and not facility_opd:
        raise ValueError(
            "Facility workbook must contain at least one sheet named 'Imaging' or 'OPD'. "
            f"Sheets found: {facility_wb.sheetnames}"
        )

    template_imaging = find_sheet(output_wb, ("Imaging",))
    template_opd = find_sheet(output_wb, ("OPD", "Outpatient"))
    if not template_imaging or not template_opd:
        raise ValueError("The standard template must contain both 'Imaging' and 'OPD' sheets.")

    imaging_count = 0
    opd_count = 0

    if facility_imaging:
        imaging_count = process_imaging(facility_wb[facility_imaging], output_wb[template_imaging])
    else:
        del output_wb[template_imaging]

    if facility_opd:
        opd_count = process_opd(facility_wb[facility_opd], output_wb[template_opd])
    else:
        del output_wb[template_opd]

    output_wb.save(output_path)
    return imaging_count, opd_count


def process_file(
    facility_file: str | Path,
    template_file: str | Path,
    output_dir: str | Path,
) -> Path:
    facility_path = Path(facility_file)
    template_path = Path(template_file)
    output_dir = Path(output_dir)

    if not facility_path.exists():
        raise FileNotFoundError(f"Facility file not found: {facility_path}")
    if not template_path.exists():
        raise FileNotFoundError(f"Template file not found: {template_path}")

    output_dir.mkdir(parents=True, exist_ok=True)
    output_path = output_dir / facility_path.name
    shutil.copy2(template_path, output_path)

    imaging_count, opd_count = populate_template(output_path, facility_path)
    print(f"Created: {output_path}")
    print(f"Imaging rows retained: {imaging_count}")
    print(f"OPD rows retained: {opd_count}")
    return output_path


def main() -> None:
    parser = argparse.ArgumentParser(description="Populate the standard Imaging and OPD template.")
    parser.add_argument("facility_file", help="Facility Excel workbook")
    parser.add_argument("template_file", help="Standard template workbook")
    parser.add_argument("--output-dir", default="output", help="Folder for completed workbooks")
    args = parser.parse_args()
    process_file(args.facility_file, args.template_file, args.output_dir)


if __name__ == "__main__":
    main()
