from pathlib import Path
from tempfile import TemporaryDirectory

import streamlit as st

from automate_imaging_opd import process_file

st.set_page_config(page_title="Imaging and OPD Automation", layout="centered")
st.title("Imaging and OPD Template Automation")
st.write("Upload one facility Excel workbook. The standard template is applied automatically.")

APP_DIR = Path(__file__).resolve().parent
TEMPLATE_PATH = APP_DIR / "Template.xlsx"

facility_upload = st.file_uploader("Facility Excel file", type=["xlsx"])

if facility_upload:
    if not TEMPLATE_PATH.exists():
        st.error("Template.xlsx is missing from the application repository.")
    else:
        with TemporaryDirectory() as tmp:
            tmp_dir = Path(tmp)
            facility_path = tmp_dir / facility_upload.name
            facility_path.write_bytes(facility_upload.getvalue())

            try:
                output_path = process_file(facility_path, TEMPLATE_PATH, tmp_dir / "output")
                st.success("The completed workbook is ready.")
                st.download_button(
                    "Download completed workbook",
                    data=output_path.read_bytes(),
                    file_name=facility_upload.name,
                    mime="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
                )
            except Exception as exc:
                st.error(str(exc))
